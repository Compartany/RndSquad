local this = {}

function this:Load()
    -- nothing to do
end

RND_GLOBAL.tool = this
return this
