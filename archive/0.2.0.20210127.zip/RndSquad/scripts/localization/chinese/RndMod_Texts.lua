return {
    squad_pbr_name = "RND[type:PBR]",
    squad_prs_name = "RND[type:PRS]",
    squad_pbs_name = "RND[type:PBS]",
    squad_description = "这些机甲掌握了随机的规律，它们总能从随机中找出最有用的武器。",
    mech_prime_name = "RND:PRIME",
    mech_brute_name = "RND:BRUTE",
    mech_ranged_name = "RND:RANGED",
    mech_science_name = "RND:SCIENCE",
    add_to_shop = "添加%s到商店"
}
