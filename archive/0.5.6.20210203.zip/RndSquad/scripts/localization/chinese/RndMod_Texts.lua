return {
    squad_prs_name = "RND[type:PRS]",
    squad_pbr_name = "RND[type:PBR]",
    squad_pbs_name = "RND[type:PBS]",
    squad_description = "这些机甲掌握了随机的规律，它们总能从随机中找出最有用的武器。",
    mech_prime_name = "RND:PRIME",
    mech_brute_name = "RND:BRUTE",
    mech_ranged_name = "RND:RANGED",
    mech_science_name = "RND:SCIENCE",
    hintTextTip_title = "随机武器",
    hintTextTip_text = "当前随机到的武器显示在左下角机甲名称处（仅在未重命名机甲时有效）。",
    addToShop = "添加%s到商店",
    resetTips_title = "重置 MOD 提示",
    resetTips_text = "重置 MOD 提示"
}
