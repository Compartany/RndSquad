local texts = RndMod_Texts

return {
    RndMechPrime = texts.mech_prime_name,
    RndMechBrute = texts.mech_brute_name,
    RndMechRanged = texts.mech_ranged_name,
    RndMechScience = texts.mech_science_name,
    HintTextTip_Title = texts.hintTextTip_title,
    HintTextTip_Text = texts.hintTextTip_text
}