return {
    squad_pbr_name = "RND[type:PBR]",
    squad_prs_name = "RND[type:PRS]",
    squad_pbs_name = "RND[type:PBS]",
    squad_description = "These Mechs have mastered the laws of randomness, and they can always find the most useful weapons from randomness.",
    mech_prime_name = "RND:PRIME",
    mech_brute_name = "RND:BRUTE",
    mech_ranged_name = "RND:RANGED",
    mech_science_name = "RND:SCIENCE",
    add_to_shop = "Add %s to shop."
}
